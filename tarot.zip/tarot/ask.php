<?
function uni2zg($uni) {
    $zg = $uni;
    $zg = str_replace('\u1004\u103a\u1039', '\u1064', $zg); // hahtoe
    $zg = preg_replace('/\u1039/', '\u103a', $zg); // kinzi
    $zg = preg_replace('/\u103a([\u103c\u103d\u103e\u102f\u1030])/', '$1\u103b', $zg); // yaapint
    $zg = preg_replace('/([\u1000-\u1021])\u1064([\u1000-\u1021])/', '$1\u1004\u103a\u1039$2', $zg); // nga-tat
    $zg = preg_replace('/([\u1000-\u1021])\u108b/', '$1\u102d\u1036', $zg); // shan-digit
    $zg = preg_replace('/([\u1000-\u1021])\u108d/', '$1\u103c', $zg); // mon-digit
    $zg = str_replace('\u103f', '\u1086', $zg); // nga-lone
    $zg = preg_replace('/\u103c([\u1000-\u1021])([\u1000-\u1021])/', '$1\u103c$2', $zg); // ta-wae-htoe
    $zg = preg_replace('/([\u1000-\u1021])\u103c([\u1000-\u1021])/', '$1\u103b$2', $zg); // yayit
    $zg = preg_replace('/([\u1000-\u1021])\u103a([\u1000-\u1021])/', '$1\u1039$2', $zg); // aukmyint
    return $zg;
}

function convert_myanmar_font($text) {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $is_zawgyi = false;
    if (strpos($user_agent, 'Firefox') !== false) {
        // Firefox uses Zawgyi as default font for some versions
        $is_zawgyi = (strpos($user_agent, 'Zawgyi') !== false);
    } else if (strpos($user_agent, 'Chrome') !== false || strpos($user_agent, 'Edge') !== false) {
        // Chrome and Edge use Unicode as default font, but Zawgyi may be installed as fallback
        $list = shell_exec('fc-list :lang=my | grep -i zawgyi');
        $is_zawgyi = (!empty($list));
    }
    if ($is_zawgyi) {
        $text = uni2zg($text);
    }
    return $text;
}

$web=<<<sss
<!doctype html>
<html>
   <head>
     <title>ဆရာသုတစိုး</title>
     <style>
        body {
           font-family: Arial, sans-serif; /* set the font for the entire page */
        }
        h1 {
           font-size: 36px; /* increase the font size of the header */
           text-align: center; /* center the header text */
        }
        form {
           margin: 0 auto; /* center the form horizontally */
           width: 50%; /* set the width of the form */
        }
        label {
           font-weight: bold; /* make the labels bold */
        }
        select, input[type="submit"] {
           display: block; /* display each form element on its own line */
           font-size: 16px; /* increase the font size of the form elements */
           margin-bottom: 10px; /* add some space between each form element */
           width: 100%; /* set the width of the form elements */
           padding: 5px; /* add some padding to the form elements */
           border-radius: 5px; /* add rounded corners to the form elements */
           border: none; /* remove the default border */
           background-color: #f2f2f2; /* set a light gray background color */
        }
        input[type="submit"] {
           background-color: #4CAF50; /* set a green background color */
           color: white; /* set the text color to white */
           cursor: pointer; /* change the mouse cursor to a pointer on hover */
        }
     </style>
        <meta charset="UTF-8">
   </head>
   <body>
    <h1>ကလေးနာမည်ပေးယံ</h1>

    <form action="name.php" method="post">
		<label for="day">ကလေး က ဘာ နေ့သားလဲ?</label>
		<select id="day" name="day" required>
			<option value="တနင်္ဂနွေ">တနင်္ဂနွေ</option>
			<option value="တနင်္လာ">တနင်္လာ</option>
			<option value="အင်္ဂါ">အင်္ဂါ</option>
			<option value="ဗုဒ္ဓဟူး">ဗုဒ္ဓဟူး</option>
			<option value="ကြာသပတေး">ကြာသပတေး</option>
			<option value="သောကြာ">သောကြာ</option>
			<option value="စနေ">စနေ</option>
		</select>
<br><br>
<label for="gender">သားလေးလား သမီးလေးလား?</label>
<select id="gender" name="gender"required>
<option value="သားလေး">သားလေး</option>
<option value="သမီးလေး">သမီးလေး</option>
</select>
<input type="submit" name="submit" value="ကလေးနာမည်ပေးမယ်။">
</form>
   </body>
</html>
sss;
echo convert_myanmar_font($web);
?>