<?php


function uni2zg($uni) {
    $zg = $uni;
    $zg = str_replace('\u1004\u103a\u1039', '\u1064', $zg); // hahtoe
    $zg = preg_replace('/\u1039/', '\u103a', $zg); // kinzi
    $zg = preg_replace('/\u103a([\u103c\u103d\u103e\u102f\u1030])/', '$1\u103b', $zg); // yaapint
    $zg = preg_replace('/([\u1000-\u1021])\u1064([\u1000-\u1021])/', '$1\u1004\u103a\u1039$2', $zg); // nga-tat
    $zg = preg_replace('/([\u1000-\u1021])\u108b/', '$1\u102d\u1036', $zg); // shan-digit
    $zg = preg_replace('/([\u1000-\u1021])\u108d/', '$1\u103c', $zg); // mon-digit
    $zg = str_replace('\u103f', '\u1086', $zg); // nga-lone
    $zg = preg_replace('/\u103c([\u1000-\u1021])([\u1000-\u1021])/', '$1\u103c$2', $zg); // ta-wae-htoe
    $zg = preg_replace('/([\u1000-\u1021])\u103c([\u1000-\u1021])/', '$1\u103b$2', $zg); // yayit
    $zg = preg_replace('/([\u1000-\u1021])\u103a([\u1000-\u1021])/', '$1\u1039$2', $zg); // aukmyint
    return $zg;
}

function convert_myanmar_font($text) {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $is_zawgyi = false;
    if (strpos($user_agent, 'Firefox') !== false) {
        // Firefox uses Zawgyi as default font for some versions
        $is_zawgyi = (strpos($user_agent, 'Zawgyi') !== false);
    } else if (strpos($user_agent, 'Chrome') !== false || strpos($user_agent, 'Edge') !== false) {
        // Chrome and Edge use Unicode as default font, but Zawgyi may be installed as fallback
        $list = shell_exec('fc-list :lang=my | grep -i zawgyi');
        $is_zawgyi = (!empty($list));
    }
    if ($is_zawgyi) {
        $text = uni2zg($text);
    }
    return $text;
}




$name=array();

if($_POST["submit"]) {
    $baby=$_POST["gender"];
if($_POST["gender"]=="သားလေး") {

    if($_POST["day"]=="တနင်္ဂနွေ") {
$name=array("အောင်ကိုသက်", "အေးမင်းကို", "အောင်မိုးကျော်", "အောင်ကိုဟိန်း", "အောင်မျိုးကျော်", "အောင်မျိုးသူ","အောင်ခိုင်မိုး");
    }
    else if($_POST["day"]=="တနင်္လာ") {
        $name= array("ကျော်သုတ", "ကျော်သူရ", "ခိုင်မင်းကို", "ခင်အောင်လွင်", "ကျော်မျိုးခိုင်", "ချန်းမင်းအောင်", "ခင်မောင်တင့်");
    }
    else if($_POST["day"]=="အင်္ဂါ") {
        $name=array("ဇော်ထက်လွင်", "ဇော်မျိုးဝင်း", "စိုးမင်းအောင်", "စိုးမင်းလပ်", "ညွံ့မောင်", "ညွံ့ဝင်း", "စိုးဇာနီ");
    }
    else if($_POST["day"]=="ဗုဒ္ဓဟူး") {
        $name=array("ဝင်းမြင့်လှိုင်", "ဝင်းလွင်ဦး", "လှိုင်မင်းဦး", "ရန်နိုင်လင်း", "လွင်ဦးထက်", "ရဲကျော်ဖျိုး", "ရန်နိုင်စိုး");
    }
    else if($_POST["day"]=="ကြာသပတေး") {
        $name=array("မိုးထက်ဇော်", "မင်းထက်သာ", "မင်းမောင်ဇော်", "ဖျိုးကျော်သူ", "ဘုန်းခန့်လွင်", "မင်းမင်းစိုး", "ဖျိုးထက်ဇော်");
    }
    else if($_POST["day"]=="သောကြာ") {
        $name=array("သက်လွင်ဦး", "ဟိန်းကျော်သူ", "သုတလင်း", "ဟိန်းထက်ဇော်", "သူရဇော်", "ဟိန်းမျိုးကျော်", "သုတအောင်");
        }
        else if($_POST["day"]=="စနေ") {
            $name=array("ထိုက်လင်းဦး", "ထင်လင်းအောင်", "ထင်လင်းထိုက်", "ထက်လင်းဦး", "ထင်အောင်ကျော်", "ထက်မင်းသူ", "တိုးတက်အောင်");
        }
        else {
            echo "နေ့နမ်ကို သေချာပြောပါ";
        }
    
}
else if($_POST["gender"]=="သမီးလေး") {
    $name=array("အိအိအောင်", "အေးမိုးသူ", "အေးအေးအောင်", "အေးရင်", "အေးအေးငြိမ်း", "အိအိငြိမ်း", "အိအိမိုး");
}
else if($_POST["day"]=="တနင်္လာ") {
    $name=array("ခင်မာအေး", "ခင်မာစိုး", "ကေသီနွယ်", "ကေသီမွန်", "ခိုင်ဇင်ကျော်", "ခင်သီဒါ", "ခင်မျတ်မိုး");
}
else if($_POST["day"]=="အင်္ဂါ") {
    $name=array("စုထက်အိန္ဒြေ", "ဇွန်ပွင့်", "စုမျတ်မိုး", "စုမျတ်ထက်", "စုစုအောင်", "စုဇာနွယ်", "ဇာလေးဖြူ");
}
else if ($_POST["day"] == "ဗုဒ္ဓဟူး") {
    // code to be executed if the condition is true
  }
  else if ($_POST["day"] == "ဗုဒ္ဓဟူး") {
    // code to be executed if the condition is true
  }
  else if ($_POST["day"] == "ဗုဒ္ဓဟူး") {
    // code to be executed if the condition is true
  }
  else if ($_POST["day"] == "ဗုဒ္ဓဟူး") {      
    $name=array("ယွန်းထက်အိန္ဒြေ", "ယွန်းဟန်နီ", "ယမင်းထိတ်ထား", "ယုယုလှိုင်", "ရွှေဇင်ဖျိုး", "လင်းလပ်မိုး", "ယုယုမော်");
}
else if($_POST["day"]=="ကြာသပတေး") {
    $name= array("မေယုဟန်နီ", "မွန်မွန်စိုး", "ဖျိုးဖျိုးဦး", "မေဖျိုးဟန်နီ", "မေမိုးဟန်နီ", "မိုးမိုးဦး", "မိုးရွှေဇင်");
}
else if($_POST["day"]=="သောကြာ") {
    $name=array("သင်းသင်းယု", "သင်းဆုမွန်", "သက်မာဖျိုး", "သီဒါအေး", "သူဇာထက်", "သိမ့်သိမ့်မိုး", "သိမ့်ထက်စိုး");
}
else if($_POST["day"]=="စနေ") {
    $name=array("ထက်မွန်အိန္ဒြေ", "ထက်ထက်ဟန်နီ", "", "တင့်တင့်ဇော်", "ထိတ်ထားဦး", "ထားသဇင်", "ထက်ယမင်း", "နီလာဖျိုး");
}
else {
    echo "သားလေးလား သမီးလေးလား?";
}

}
else {
    header("Location:ask.php");
}
$rn=array_rand($name);
$nit=$name[$rn];
$e="အယူတော်မင်္ဂလာဦးနိုးကို နိုင်ငံ ကျော်ထင်ရှားစေချင်တဲ့အတွက် ဗေဒင်ပညာ ရှင်များဖြစ်တဲ့မိဘ နှစ်ပါးက မောင်နိုးလို့ အမည်ပေးခဲ့ပါတယ်<br> ထို့အတူအလောင်းမင်းတရားကြီးက သူ့ရဲ့ သွေးသောက်တစ်ဦးဖြစ်တဲ့ ငဆံကို အမည်ခိုက်မှာစိုး၍ ငညိုသူ လို့ အမည်ပြောင်းလဲပေးခဲ့ပါတယ်။<br> ဆိုတော့ ဆရာပြောချင်တာက ဇဘူဒီပါတောင်ကျွန်းသြဘာနိမိတ်ထွန်းဆိုတဲ့မြန်မာစကားဆိုနဲ့အညီ". $baby . "ကိုဆရာက ". $nit . "လို့နာမည်ပေးချင်ပါတယ်။<br>"
."ဒီနေ့ကစ". $nit . "အသက်၁၂၀ ရှေစေသော်";
echo convert_myanmar_font($e);
?>