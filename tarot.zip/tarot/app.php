<?php
$web = <<<sss
<!doctype html>
<html>
    <head>
        <link rel="stylesheet" href="styles.css">
        <meta charset="UTF-8">
        <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-QCDT4WEHD8"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-QCDT4WEHD8');
</script>
        <title>
            ဉာဏ်ရည်တု ဗေဒင်ဆရာ
        </title>
    </head>
    <body>
        <div>
        <h1>ဉာဏ်ရည်တုဗေဒင်ဆရာ</h1>
        <p>
            ကျွန်တော်တို့ website က နေ အသေးစားဉာဏ်ရည်တု နည်းပညာကို သုံးပြီး အခမဲ့ ဗေဒင်ဟောပေးနေပါတယ်။
        </p>
    </div>
    <br><a href='name.html'>ကလေးနာမည် ပေးချင်ရင်ဒီကို နှိပ်ပါ</a><br><br>
        <form action="tarot.php" method="post">
            <div>
            <input type="text" name="userName" placeholder="မိတ္ဆွေရဲ့ နာမည်ပြောပါ" required>
        </div>
        <br><br>
        <div>
            <input type="number" name="age" placeholder="အသက် ဘယ်လောက်လဲ" required>
        </div>
            <br><br>
            <div>
            <label for="male">မိတ္ဆွေက အမျိုးသားလား?</label>
            <input id="male" type="radio" name="gender" value="အမျိုးသား" required>
            <label for="female">မိတ္ဆွေက အမျိုးသမီးလား?</label>
            <input id="female" type="radio" name="gender" value="အမျိုးသမီး" required>
        </div>
        <br><br><br>
        <div>
            <input type="submit" name="submit" value="စမေးမယ်">
        </div>
        </form>
    </body>
</html>
sss;

function convert_myanmar_font($text) {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $is_zawgyi = false;
    if (strpos($user_agent, 'Firefox') !== false) {
        // Firefox uses Zawgyi as default font for some versions
        $is_zawgyi = (strpos($user_agent, 'Zawgyi') !== false);
    } else if (strpos($user_agent, 'Chrome') !== false || strpos($user_agent, 'Edge') !== false) {
        // Chrome and Edge use Unicode as default font, but Zawgyi may be installed as fallback
        $list = shell_exec('fc-list :lang=my | grep -i zawgyi');
        $is_zawgyi = (!empty($list));
    }
    if ($is_zawgyi) {
        $text = uni2zg($text);
    }
    return $text;
}

function uni2zg($uni) {
    $zg = $uni;
    $zg = str_replace('\u1004\u103a\u1039', '\u1064', $zg); // hahtoe
    $zg = preg_replace('/\u1039/', '\u103a', $zg); // kinzi
    $zg = preg_replace('/\u103a([\u103c\u103d\u103e\u102f\u1030])/', '$1\u103b', $zg); // yaapint
    $zg = preg_replace('/([\u1000-\u1021])\u1064([\u1000-\u1021])/', '$1\u1004\u103a\u1039$2', $zg); // nga-tat
    $zg = preg_replace('/([\u1000-\u1021])\u108b/', '$1\u102d\u1036', $zg); // shan-digit
    $zg = preg_replace('/([\u1000-\u1021])\u108d/', '$1\u103c', $zg); // mon-digit
    $zg = str_replace('\u103f', '\u1086', $zg); // nga-lone
    $zg = preg_replace('/\u103c([\u1000-\u1021])([\u1000-\u1021])/', '$1\u103c$2', $zg); // ta-wae-htoe
    $zg = preg_replace('/([\u1000-\u1021])\u103c([\u1000-\u1021])/', '$1\u103b$2', $zg); // yayit
    $zg = preg_replace('/([\u1000-\u1021])\u103a([\u1000-\u1021])/', '$1\u1039$2', $zg); // aukmyint
    return $zg;
}

$change=convert_myanmar_font($web);

echo $change
?>